<!DOCTYPE html>
<html>

<head>
</head>
<body>
	<div style="padding-left: 20px;">
		<p>Xóa từ ngày <?php echo e($oneMonth); ?> trờ về trước: còn lại <?php echo e($number); ?></p>
		<?php if($count >=0): ?>
		<p>Đã xóa <?php echo e($count); ?></p>
		<?php endif; ?>
		<?php echo Form::model(null, array('route' => array('portal.agent.delete'))); ?>

			<button type="submit">Xóa</button>	
		<?php echo Form::close(); ?>

	</div>
</body>
</html>