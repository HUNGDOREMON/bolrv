<?php $__currentLoopData = $LEFT_MENU; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="widgetPanel sportsMenu special" ng-class="{'collapse': !menu.<?php echo e($i); ?>}">
        <div class="glyphIcon icon-widgetCollapse" title="Collapse the Widget Panel"></div>
        <div class="heading <?php echo e($menu->getIcon()); ?> currentMain" title="Mọi môn thể thao"
            ng-click="menu.<?php echo e($i); ?>=!menu.<?php echo e($i); ?>">

            <?php if($menu->getType() == 'menu'): ?>
                <div class="text">
                    <?php echo e($menu->getName()); ?>

                </div>
                <span
                    ng-class="{'icon-arrowCircle-down': !menu.<?php echo e($i); ?>, 'icon-arrowCircle-up': menu.<?php echo e($i); ?>}" />
            <?php endif; ?>
            <?php if($menu->getType() == 'link'): ?>
                <div class="text">
                    <?php echo e($menu->getName()); ?>

                </div>
                <!--<span class="c-icon c-icon--foreign" />-->
            <?php endif; ?>
            <?php if($menu->getType() == 'sabagame'): ?>
                <div class="text" onClick="openSabagame()">
                    <?php echo e($menu->getName()); ?>

                </div>

                <script>
                    function getCookie(name) {
                        const value = `; ${document.cookie}`;
                        const parts = value.split(`; ${name}=`);
                        if (parts.length === 2) return parts.pop().split(';').shift();
                    }

                    function openSabagame(e) {
                        popupwindow('<?php echo e(env('SABAGAME_URL')); ?>?session=' + getCookie('laravel_session') + '&domain=' + window.location
                            .protocol +
                            '//' + window.location.host, 800, 500)

                    }

                    function popupwindow(url, title, w, h) {
                        var left = (screen.width / 2) - (w / 2);
                        var top = (screen.height / 2) - (h / 2);
                        return window.open(url, title,
                            'toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no, width=' +
                            w + ', height=' + h + ', top=' + top + ', left=' + left);
                    }
                </script>
            <?php endif; ?>

        </div>
        <?php
        $sports = $menu->getSports();
        $sports_idselected = $sports ? $menu->getSports()->getIdSelected() : -1;
        $sports_items = $sports ? $menu->getSports()->getItems() : [];
        $sports_selected = $sports ? $sports_items[$sports_idselected] : null;
        
        $show_list = null;
        $index = -1;
        
        if ($menu->getSubMenu() != null) {
            if (count($menu->getSubMenu()) > 10) {
                $show_list = array_chunk($menu->getSubMenu(), 6);
                $index = 0;
            } else {
                $show_list = [0 => $menu->getSubMenu()];
                $index = 0;
            }
        }
        
        ?>
        <?php if($menu->getType() && $menu->getType() != 'link'): ?>
            <div class="contentArea">
                <div class="nav-widgetPanel  icon-sportsMenu-today threeColum">
                    <?php $__currentLoopData = $sports_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y => $submenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item <?php echo e($sports_idselected == $y ? 'active' : ''); ?> icon-sportsMenu-early"
                            title="<?php echo e($submenu->getName()); ?>"><span class="itemContent"><span
                                    class="text"><?php echo e($submenu->getName()); ?></span></span></div>
                        <!--<div class="item  icon-sportsMenu-live" title="Trực tiếp">-->
                        <!--	<span class="itemContent">-->
                        <!--		<span class="text">Trực tiếp</span>-->
                        <!--		<div class="alertArea">-->
                        <!--			<div class="alert">68</div>-->
                        <!--		</div>-->
                        <!--	</span>-->
                        <!--</div>-->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <ul class="category today">
                    <?php if($sports_selected != null): ?>
                        <li class="category-sportList icon-sport1">
                            <div class="category-sportList-container">
                                <div class="category-sportList-main"
                                    title="<?php echo e($sports_selected->getSubMenu()->getTop()->getName()); ?>">
                                    <span class="sportName">
                                        <?php echo e($sports_selected->getSubMenu()->getTop()->getName()); ?>

                                    </span>
                                    <span class="amount">
                                        (<?php echo e($sports_selected->getSubMenu()->getTop()->getValue()); ?>)
                                    </span>
                                </div>
                                <div class="floatRight">
                                    <?php if($sports_selected->getSubMenu()->getTop()->getIsLive()): ?>
                                        <button class="flexible accent smallBtn btn-live">
                                            Trực tiếp
                                        </button>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <ul class="category-sub">
                                <?php $__currentLoopData = $sports_selected->getSubMenu()->getSports(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y => $submenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="category-sub-list">
                                        <a href="<?php echo e($submenu->getLink()); ?>"><span class="betTypeName" style="
                                            float: left;
                                            color: #545454;
                                        " title="<?php echo e($submenu->getName()); ?>"><?php echo e($submenu->getName()); ?></span>
                                            <span class="amount " style="
                                        float: left;
                                        color: #545454;
                                    ">(<?php echo e($submenu->getValue()); ?>)</span>
                                        </a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </li>
                    <?php endif; ?>
                    <?php if($index >= 0): ?>
                        <?php $__currentLoopData = $show_list[$index]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y => $submenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="category-sportList <?php echo e($submenu->getIcon()); ?>">
                                <div class="category-sportList-container">
                                    <div class="category-sportList-main" title="<?php echo e($submenu->getName()); ?>">
                                        <a href="<?php echo e($submenu->getLink()); ?>">
                                            <span class="sportName" style="
                                            float: left;
                                            color: #545454;
                                        " title="<?php echo e($submenu->getName()); ?>"><?php echo e($submenu->getName()); ?></span>
                                            <?php if($submenu->getValue() != '' && $submenu->getValue() != null): ?>
                                                <span class="amount" style="color: #545454;">(<?php echo e($submenu->getValue()); ?>)</span>
                                            <?php endif; ?>
                                        </a>
                                    </div>
                                    <?php if($submenu->getIsNew()): ?>
                                        <div class="floatRight"><span class="smallBtn flexible icon-new">Mới</span>
                                        </div>
                                    <?php else: ?>
                                        <div class="floatRight">
                                            <?php if($submenu->getIsLive()): ?>
                                                <button class="flexible accent btn-live smallBtn">Trực tiếp</button>
                                            <?php endif; ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if($index < count($show_list) - 1): ?>
                            <button class="category-sportList show-more">
                                <span>Xem thêm</span>
                                <span class="icon-arrow-down">

                                </span>
                            </button>
                        <?php endif; ?>
                    <?php endif; ?>
                </ul>
            </div>
        <?php endif; ?>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
