<!DOCTYPE html>
<html>

<head>
    <meta content="text/html; charset=utf-8" http-equiv="Content-Type">

    <title>Bet List</title>
    <link href="/assets/admin/css/chitietthangthua_files/Agent.min.css" rel="stylesheet" type="text/css">
    <link href="/assets/admin/css/chitietttmb_files/BetList.css" rel="stylesheet" type="text/css">
    <link href="/assets/admin/css/chitietthangthua_files/DateRangeSelect.min.css" rel="stylesheet" type="text/css">
    <link href="/assets/admin/css/chitietthangthua_files/jscal2.min.css" rel="stylesheet" type="text/css">
    <link href="/assets/admin/css/chitietthangthua_files/steel.min.css" rel="stylesheet" type="text/css">
    <style type="text/css">
        .jlhlebbhengjlhmcjebbkambaekglhkf {top: 0px; left: 0px;min-width: 30px;max-width: 300px;font-size: 13px;font-family: arial, helvetica, sans-serif;opacity: .93;padding:0px;position:absolute;display:block;z-index: 999997;font-style: normal;font-variant: normal;font-weight: normal;}#jlhlebbhengjlhmcjebbkambaekglhkf_up{text-align: center;padding:0px;margin: 0px;}#jlhlebbhengjlhmcjebbkambaekglhkf_cont{background-color: #729FCF;font-family: arial, helvetica, sans-serif-webkit-box-shadow: #729FCF 0px 0px 2px;color: #FFFFFF;padding:7px;-webkit-border-radius: 5px;}#jlhlebbhengjlhmcjebbkambaekglhkf_down{text-align: center;padding:0px;margin: 0px;}
    </style>
    <style type="text/css">
        .pagination{
          display: inline-flex;
          list-style: none;
          font-size: 18px;
        }
        .pagination li{
          padding-right: 10px; 
        }
      </style>
    <script>
        function showP(n)
        {
             var a = 'divEvent_' + n;
             var divEvent = document.getElementById(a);
            if (divEvent.style.display == 'none') {
                divEvent.style.display = '';
            }
            else 
            {
                divEvent.style.display = 'none';
            }
        }

        function httpGetAsync(theUrl, callback) {
          var xmlHttp = new XMLHttpRequest();
          xmlHttp.onreadystatechange = function() { 
            if (xmlHttp.readyState == 4 && xmlHttp.status == 200)
              callback(xmlHttp.responseText);
          }
          xmlHttp.open("GET", theUrl, true); // true for asynchronous 
          xmlHttp.send(null);
        }

        function onDeleteItem(id) {
          var r = confirm('Bạn chắc chắn muốn xóa item '+ id);
          if (r) {
            httpGetAsync('api/bets/'+id+'/delete' , function () {
              location.reload();  
            })
          }
        }
    </script>
</head>

<body style="margin-left: 10px;">
    <?php echo $__env->make('portal.messsage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="bl_title">
        Lịch sử hoạt động
    </div>

    <div id="spData">
        <form method="get" action="" id="frm" name="frm">
            <table>
            <tbody>
            <tr>
                <td>
                    <div id="box_header">
                        <table style="width: 100%">
                            <tbody>
                            <tr>
                                <td>
                                    <script src="/assets/admin/js/chitietthangthua_files/DateRangeSelect.js" type="text/javascript"></script><script type="text/javascript">
                                        var max_server_date = '11/6/2014';
                                    </script>
                                    <div id="spDateTimeSearch">
                                        <table border="0" cellpadding="0" cellspacing="0">
                                            <tbody>
                                            <tr style="height: 32px;">
                                                <td class="l" id="tdfdatetext" style="padding-left: 6px;">
                                                    <span id="spfdatetext">Từ:</span>
                                                </td>
                                                <td class="l" id="tdFromDateCal">
                                                      <span id="spFromDateCal">
                                                      </span>
                                                    <script src="/assets/admin/js/chitietthangthua_files/jscal2.js" type="text/javascript"></script>
                                                    <script src="/assets/admin/js/chitietthangthua_files/en.js" type="text/javascript"></script>
                                                    <table border="0" cellspacing="0">
                                                        <tbody>
                                                        <tr>
                                                            <td>
                                                                <input class="date_no" id="fdate" name="start_date" readonly="readonly" size="13" type="text" value="<?php echo e($req->start_date); ?>">
                                                            </td>
                                                            <td>
                                                                <input alt="" id="fdate_trigger" onclick="javascript:return false;" src="/assets/admin/images/calendar.png" style="width: 30px;cursor: pointer" title="Date selector" type="image"><!-- <img alt="" src="/_GlobalResources/Images/cal.gif" id="fdate_trigger" title="Date selector"style="margin: 0px; cursor: pointer" /> -->
                                                            </td>
                                                        </tr>
                                                        </tbody>
                                                    </table>
                                                    <span id="spFromDateCal">
                                                         <script type="text/javascript">
                                                            function CalendarOnSelect() {if($("ddlSelectDate"))$("ddlSelectDate").value = 8;}var fdate = Calendar.setup({animation:false,trigger: "fdate_trigger",inputField: "fdate",min: 20180101, max: <?php echo e(date('Ymd')); ?>,dateFormat: "%m/%d/%Y",weekNumbers:true,onSelect: function() {CalendarOnSelect();this.hide();}});
                                                         </script>
                                                      </span>
                                                </td>
                                                <td class="l" id="tdtdatetext">
                                                    &nbsp;&nbsp;
                                                    <span id="sptdatetext"> đến:</span>
                                                </td>
                                                <td class="l" id="tdToDateCal">
                                                      <span id="spToDateCal">
                                                      </span>
                                                    <table border="0" cellspacing="0">
                                                        <tbody>
                                                        <tr>
                                                            <td>
                                                                <input id="tdate" name="end_date" class="date_no" value="<?php echo e($req->end_date); ?>" type="text" size="13" readonly="readonly">
                                                            </td>
                                                            <td>
                                                                <input type="image" alt="" src="/assets/admin/images/calendar.png" id="tdate_trigger" title="Date selector" style="width: 30px;cursor: pointer" onclick="javascript:return false;">
                                                            </td>
                                                        </tr>
                                                        </tbody>
                                                    </table>
                                                    <script type="text/javascript">
                                                        function CalendarOnSelect() {if($("ddlSelectDate"))$("ddlSelectDate").value = 8;}var tdate = Calendar.setup({animation:false,trigger: "tdate_trigger",inputField: "tdate",min: 20180101,max: <?php echo e(date('Ymd')); ?>,dateFormat: "%m/%d/%Y",weekNumbers:true,onSelect: function() {CalendarOnSelect();this.hide();}});
                                                    </script>
                                                </td>
                                                <td class="l">
                                                    &nbsp;&nbsp;<input class="btn" id="dSubmit" onclick="" style="" type="submit" value="Xem">&nbsp;
                                                    <input class="btn" id="dToday" onclick="top.main.location='?start_date=<?php echo e($today); ?>&end_date=<?php echo e($today); ?>'" style="width: 100px" type="button" value="<?php echo e($today); ?>">&nbsp;
                                                    <input class="btn" id="dYesterday" onclick="top.main.location='?start_date=<?php echo e($yesterday); ?>&end_date=<?php echo e($yesterday); ?>'" style="width: 100px" type="button" value="<?php echo e($yesterday); ?>">
                                                </td>
                                                <td valign="top">
                                                    <div class="" id="loading" style="float: left;">
                                                    </div>
                                                </td>
                                            </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                        <div class="warning l" id="dvMsg" style="margin-bottom: 5px; margin-top: 10px; padding:0 2px;">
                            <ul>
                                <li>
                                    <span id="spMsg">
                                    Bạn có thể xem dữ liệu báo cáo từ <?php echo e($firstDate); ?> đến <?php echo e($today); ?>.
                                    </span>
                                </li>
                            </ul>
                        </div>
                    </div>
                </td>
            </tr>
            </tbody>
        </table>
        </form>
        <table id="hor-minimalist-a">
            <thead>
                <tr>
                    <th style="width: 20px;">#</th>
                    <th style="width: 110px;">Thành viên</th>
                    <th style="width: 110px;">Thời gian</th>
                    <th style="width: 50px;">Loại</th>
                    <th>Thay đổi</th>
                </tr>
            </thead>

            <tbody>
                <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr id="<?php echo e($value->id); ?>">
                    <td class="w-order"><?php echo e($key + 1); ?></td>
                    <td class="w-order">
                     <a class="downline_link">
                      <?php echo e($value->user_name); ?>

                  </a>
                    </td>

                    <td class="c nonbreak">
                        Ref No: 
                        <?php if($value->type == 'update_bet'): ?>
                        <a href="<?php echo route('portal.web.updateBetInSaoke', ['id' => $value->related_id]); ?>"><?php echo e($value->related_id); ?></a>
                        <?php elseif($value->type == 'update_event'): ?>
                        <a href="<?php echo route('portal.web.updateEvent', ['id' => $value->related_id]); ?>"><?php echo e($value->related_id); ?></a>
                        <?php else: ?>
                        <?php echo e($value->related_id); ?>

                        <?php endif; ?>
                        <div class="time"><?php echo e($value->created_at); ?></div>
                    </td>

                    <td class="bl_underdog nonbreak">
                        <span class="oddstype"><?php echo e($value->getTypeName()); ?></span>
                    </td>

                    <td class="r bl_evt">
                        <div>
                            <div class="">
                                <div class="bettype">
                                    <?php echo e($value->bet_type); ?>

                                </div>
                                <?php $__currentLoopData = $value->extra; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="match">
                                    <span><?php echo e($item['name']); ?></span>
                                    <span>:</span>
                                    <span><?php echo e($item['from']); ?></span>
                                    <?php if($value->type !== 'delete_bet'): ?>
                                    <span> => </span>
                                    <span><?php echo e($item['to']); ?></span>
                                    <?php endif; ?>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
               <tr>
                  <td colspan="8">
                     <?php echo e($logs->links()); ?>

                  </td>
               </tr>
            </tfoot>
        </table>
    </div>

    <div class="comm_note">
        <div class="title">
            <span>Ghi chú</span>
        </div>

        <div class="content">
            <!--Com. is rounded for reference only. Therefore, Subtotal Com. amount
   may be different from the sum of Com. when it sums all the actual
   Com. amounts.-->
        </div>
    </div> 
</body>

</html>