<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <link href="https://mylv.fts368.com/App_Themes/Resources/aliceblue/aliceblue.streaming.css?2017050222" rel="stylesheet" />
</head>
<body>
    <iframe id="video-source" allowfullscreen="true" width="100%" height="100%" 
    src="https:<?php  echo $src;  ?>"></iframe>
</body>
</html>
