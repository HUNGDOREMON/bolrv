<?php $__env->startSection('menu', 'statement'); ?>
<?php $__env->startSection('main'); ?>
<div class="account">
  <!--start-->
  <div class="content">

    <div class="caption">
      <div class="filterArea ">
        <div class="filter icon-print hiddenElement " title="Print This Page "></div>
        <div class="filter icon-refresh  " title="Tải Lại" onclick="window.location.reload();"> </div>
      </div>
      <div class="mainTitle icon-statement">Sao Kê</div>
    </div>
    <ul class="tabNav-BottomLine">
      <li class="<?php  if($type== 'soccer') echo 'active';  ?>" onclick="location.href='/statement.aspx?type=soccer'">Bóng đá</li>
      <li class="<?php  if($type== 'sabagame') echo 'active';  ?>" onclick="location.href='/statement.aspx?type=sabagame'">Sabagame</li>
    </ul>
    <?php if($type== 'soccer'): ?>
    <div id="SockerContainer" class="SockerContainer">
      <div class="accountTable">
        <div class="tableHead">
          <div class="date-smaller">Ngày</div>
          <div class="remark">Ghi Chú</div>
          <div class="turnover">Lượng tiền</div>
          <div class="credit">Tín Dụng/Ghi Nợ</div>
          <div class="commission">Hoa Hồng</div>
          <div class="balance">Tài Khoản</div>
          <div class="other"></div>
        </div>
        <div class="tableBody">
          <?php $__currentLoopData = $betsDone; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="tableRow-pointer" onclick="javascript:window.location.href='<?php echo route('web.statementDetails', ['date'=>$value->date, 'type'=> 'done']); ?>'" style="cursor: pointer;">
            <div class="date-smaller">
              <div><?php echo e(date('D', strtotime($value->date))); ?></div>
              <div><?php echo e($value->date); ?></div>
            </div>
            <div class="remark">
              <div>BET</div>
              <div>- Đã xử lý (<?php echo e($value->count); ?>)</div>
            </div>
            <div class="balance"><?php echo e(format_number_pretty($value->stake)); ?></div>
            <div class="balance <?php echo e($value->profit < 0 ? 'accent' : ''); ?>"><?php echo e(format_number_pretty($value->profit)); ?></div>
            <div class="commission"><?php echo e(format_number_pretty($value->commission)); ?></div>
            <div class="balance <?php echo e($value->profit + $value->commission < 0 ? 'accent' : ''); ?>"><?php echo e(format_number_pretty($value->profit + $value->commission)); ?></div>
            <div class="other">
              <div class="smallBtn  primary icon-next" title=""></div>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    </div>
    <?php elseif($type == 'sabagame'): ?>
      <?php echo $__env->make('web.v2.iframe.sabagame', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endif; ?>
    <div class="note">
      <div class="title">Lưu ý</div>
      <div class="txt">Xin lưu ý rằng thời gian hiển thị dựa trên GMT +8 giờ.</div>
    </div>

  </div>
  <!--end-->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.v2.iframe.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>