<ul class="tabNav-BottomLine">
 <?php $__currentLoopData = $sabagame; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <li class="<?php  if($key== $game) echo 'active';  ?>" onclick="location.href='/statement.aspx?type=sabagame&game=<?php echo e($key); ?>'"><?php echo e($value['title']); ?></li>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php if($game == 'taixiu'): ?> 
  <?php echo $__env->make('web.v2.iframe.sabagame.taixiu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php elseif($game == 'xocdia'): ?>
  <?php echo $__env->make('web.v2.iframe.sabagame.taixiu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endif; ?>
