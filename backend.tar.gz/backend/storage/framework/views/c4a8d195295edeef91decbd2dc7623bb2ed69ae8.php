<html xmlns="http://www.w3.org/1999/xhtml"><head>
          <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <title>
              </title>
      
      <style type="text/css">
      </style>
      <style type="text/css">
            html
{
  color: #171717;
  cursor: default;
  font-family: Tahoma,Arial,helvetica,sans-serif;
  font-size: 11px;
  margin: 0;
  text-align: left;
}

::-webkit-scrollbar
{
  height: 16px;
  overflow: visible;
  width: 16px;
}
::-webkit-scrollbar-button
{
  height: 0;
  width: 0;
}

::-webkit-scrollbar-track
{
  background-clip: padding-box;
  border: solid transparent;
  border-width: 0 0 0 4px;
}
::-webkit-scrollbar:vertical
{
  width: 11px;
}
::-webkit-scrollbar:horizontal
{
  height: 11px;
}
::-webkit-scrollbar-track:horizontal
{
  border-width: 4px 0 0;
}
::-webkit-scrollbar-track:hover
{
  background-color: rgba(0,0,0,.05);
  box-shadow: inset 1px 0 0 rgba(0,0,0,.1);
}
::-webkit-scrollbar-track:horizontal:hover
{
  box-shadow: inset 0 1px 0 rgba(0,0,0,.1);
}
::-webkit-scrollbar-track:active
{
  background-color: rgba(0,0,0,.05);
  box-shadow: inset 1px 0 0 rgba(0,0,0,.14),inset -1px 0 0 rgba(0,0,0,.07);
}
::-webkit-scrollbar-track:horizontal:active
{
  box-shadow: inset 0 1px 0 rgba(0,0,0,.14),inset 0 -1px 0 rgba(0,0,0,.07);
}
::-webkit-scrollbar-thumb
{
  background-color: rgba(0,0,0,.2);
  background-clip: padding-box;
  border: solid transparent;
  border-width: 1px 1px 1px 6px;
  min-height: 28px;
  padding: 100px 0 0;
  box-shadow: inset 1px 1px 0 rgba(0,0,0,.1),inset 0 -1px 0 rgba(0,0,0,.07);
}
::-webkit-scrollbar-thumb:horizontal
{
  border-width: 6px 1px 1px;
  padding: 0 0 0 100px;
  box-shadow: inset 1px 1px 0 rgba(0,0,0,.1),inset -1px 0 0 rgba(0,0,0,.07);
}
::-webkit-scrollbar-thumb:hover
{
  background-color: rgba(0,0,0,.4);
  box-shadow: inset 1px 1px 1px rgba(0,0,0,.25);
}
::-webkit-scrollbar-thumb:active
{
  background-color: rgba(0,0,0,0.5);
  box-shadow: inset 1px 1px 3px rgba(0,0,0,0.35);
}
::-webkit-scrollbar-corner
{
  background: transparent;
}
body::-webkit-scrollbar-track-piece
{
  background-clip: padding-box;
  background-color: #f5f5f5;
  border: solid #fff;
  border-width: 0 0 0 3px;
  box-shadow: inset 1px 0 0 rgba(0,0,0,.14),inset -1px 0 0 rgba(0,0,0,.07);
}
body::-webkit-scrollbar-track-piece
{
  border-width: 3px 0 0;
  box-shadow: none;
}
body::-webkit-scrollbar-thumb
{
  border-width: 1px 1px 1px 1px;
}
body::-webkit-scrollbar-thumb:horizontal
{
  border-width: 1px 1px 1px;
}
body::-webkit-scrollbar-corner
{
  background-clip: padding-box;
  background-color: #f5f5f5;
  border: solid #fff;
  border-width: 3px 0 0 3px;
  box-shadow: inset 1px 1px 0 rgba(0,0,0,.14);
}

body
{
  background: #f2f4f6 url(../Images/bg_conts.jpg) repeat-x top;
  background-attachment: fixed;
  background-color: #f5f6f8;
  margin: 0;
  padding: 2px;
}

input[type=button]
{
  -moz-border-radius: 3px;
  -webkit-border-radius: 3px;
  border-radius: 3px;
  font-size: 11px;
}

select
{
  font-size: 11px;
  height: 20px;
  margin-right: 7px;
  margin-top: 1px;
}

.btn
{
  background: url(../Images/bg_buttonsite.jpg) repeat-x top;
  border: 1px #4d4d4d solid;
  cursor: pointer;
  font-size: 11px;
  height: 19px;
  line-height: 15px;
  padding: 0 5px 2px;
}

.btn:hover
{
  background: url(../Images/bg_buttonsiteOV.jpg) repeat-x top;
  border: 1px #984d1a solid;
  color: #cc4800;
}

.editBtn
{
  background: url(../Images/edit.gif) repeat-x top;
  border: solid 0 #000;
  cursor: pointer;
  height: 17px;
  width: 17px;
}

.editBtnDisabled
{
  background: url(../Images/edit_disabled.gif) repeat-x top;
  border: solid 0 #000;
  cursor: pointer;
  height: 17px;
  width: 17px;
}

.viewBtn
{
  background: url(../Images/view_icon.gif) repeat-x top;
  border: solid 0 #000;
  cursor: pointer;
  height: 17px;
  width: 17px;
}

.viewMenuBtn
{
  background: url(../Images/sticky-arrow.png) repeat-x top;
  border: solid 0 #000;
  cursor: pointer;
  height: 17px;
  width: 17px;
}

.disabledBtn
{
  background: url(../Images/disable_icon.gif) repeat-x top;
  border: solid 0 #000;
  cursor: pointer;
  height: 17px;
  width: 17px;
}

.syncBtn
{
  background: url(../Images/sync.gif) repeat-x top;
  border: solid 0 #000;
  cursor: pointer;
  height: 17px;
  width: 17px;
}

.divHeader
{
  background: transparent url(../Images/bg_header01.jpg) no-repeat scroll left bottom;
  color: #9D1C1C;
  font-weight: 700;
  height: 22px;
  line-height: 18px;
  padding-left: 15px;
  text-transform: uppercase;
  width: 97%;
}

.tblRpt
{
  background-color: #B7B7B7;
}

.RptSubTitle
{
  background-color: #ffefde;
}

.RptTitle
{
  background-color: #fff;
  font-weight: 400 !important;
  height: 22px;
  text-align: center;
  text-transform: uppercase;
}

.RptHeader
{
  background: #6A6969 url(../Images/bg_header02.jpg) repeat-x scroll center top;
  color: #FFF;
  font-size: 12px !important;
  font-weight: 400 !important;
  height: 22px;
  text-align: center;
}

.RptHeader02
{
  background-color: #3f3f3f;
  color: #FFF;
  font-size: 12px !important;
  font-weight: 400 !important;
  text-align: center;
}

.RptHeader01
{
  background: url(../Images/bg_header04.jpg) repeat-x top;
  background-color: #e8e8e8;
  font-weight: 700;
  height: 22px;
  text-align: center;
}

.RptFooter
{
  background: url(../Images/bg_f01.jpg) repeat-x scroll center top #783819;
  color: #FFF;
  font-weight: 700;
}

.w-order
{
  color: #7d7d7d;
  font-weight: 400;
  text-align: right;
  width: 20px;
}

.l
{
  text-align: left;
}

.r
{
  text-align: right;
}

.c
{
  text-align: center;
}

.b
{
  font-weight: 700;
}

.bl_time
{
  color: #434343;
  font-size: 7pt !important;
  font-weight: 400;
  text-align: center;
}

.bg_white
{
  background-color: #fff;
}

.bg_eb
{
  background-color: #F7F0E4;
}

.bg_eb2
{
  background-color: #f7f0e4;
}

.MaskLoadingDiv
{
  background: url(../Images/loader3.gif);
}

.PwdError
{
  background: url(../Images/x5.gif);
  background-repeat: no-repeat;
  border-width: 0;
  display: inline-block;
  height: 16px;
  width: 16px;
}

.PwdSuccess
{
  background: url(../Images/tick.png);
  background-repeat: no-repeat;
  border-width: 0;
  display: inline-block;
  height: 16px;
  width: 16px;
}

.tick
{
  background: url("../Images/tick.png") no-repeat center top;
  padding-left: 5px;
  letter-spacing: 10px;
  font-size: 12px;
}

#page_main
{
  overflow-x: visible;
  overflow-y: visible;
  padding-bottom: 15px;
  padding-top: 7px;
}

#header_main
{
  background: url(../Images/bg_header01.jpg) no-repeat left bottom;
  color: #9d1c1c;
  font-weight: 700;
  height: 22px;
  line-height: 18px;
  min-width: 650px;
  padding-left: 15px;
  text-transform: uppercase;
  width: 97%;
}

.positive
{
  color: #036;
  font-weight: 700;
}

.negative
{
  color: #B50000;
  font-weight: 700;
}

.iplink
{
  color: #06C;
  text-decoration: none;
}

.iplink:hover
{
  color: #F60;
  text-decoration: none;
}

.ipnolink
{
  text-decoration: none;
}

.firstCol
{
  background-color: #D8FBE5;
  color: #FF5A00;
  text-transform: uppercase;
}

.warning li
{
  background: url(../Images/more.gif) no-repeat left;
  padding-left: 20px;
}

.warning ul
{
  color: #90979a;
  font-weight: 700;
  list-style: none;
  margin-left: 2px;
  padding-left: 2px;
}

.nowrap
{
  white-space: nowrap;
}

.tblPop
{
  background-color: #cdcdcd;
}

.header_popup
{
  background: url(../Images/icon_pop.jpg) no-repeat left;
  color: #862626;
  font-size: 11px;
  font-weight: 700;
  line-height: 25px;
  padding-left: 20px;
}

div.loading
{
  background: url(../Images/ajax-loader.gif) no-repeat scroll center top transparent;
  display: block;
  height: 23px;
  opacity: 1;
  width: 23px;
}

.hidden
{
  display: none;
}

element.style
{
  cursor: pointer;
}
.clearBlock
{
  clear: both;
}
@media  only screen and (min-width: 600px) {
  .minWidthCustomer
  {
    width: 845px;
  }
  .headerBetSetting
  {
    width: 843px;
  }
}
.float_l
{
  float: left;
}
.pt3
{
  padding-top: 3px;
}
.pb3
{
  padding-bottom: 3px;
}
.pt7
{
  padding-top: 7px;
}
.hide
{
  display: none;
}
.nowrap
{
  white-space: nowrap;
}
.prewrap
{
  white-space: pre-wrap;
}
.customerInfo
{
  background-color: #F7F0E4;
  border-right: 1px solid #B7B7B7;
  float: left;
  min-width: 840px;
  padding: 0;
  width: 100%;
}
.textBoxInfo
{
  height: 18px;
  margin: 0;
  padding: 0;
  width: 120px;
}
.textBoxCredit
{
  text-align: right;
}
.textBoxComm
{
  width: 60px !important;
  margin: 0;
  padding: 0;
  height: 18px;
  text-align: right;
}
.customerInfoBlock1
{
  border-left: 1px solid #B7B7B7;
  border-top: 1px solid #B7B7B7;
  float: left;
  height: 22px;
  line-height: 22px;
  margin: 0 0 0 1px;
  padding: 2px 1px 1px;
  text-align: right;
  vertical-align: middle;
  width: 180px;
} 
.customerInfoBlock2
{
  border-left: 1px solid #B7B7B7;
  border-top: 1px solid #B7B7B7;
  float: left;
  height: 22px;
  line-height: 22px;
  margin: 0 0 0 1px;
  padding: 2px 1px 1px;
  text-align: left;
  vertical-align: middle;
  width: 335px;
}
.customerInfoBlock2NoBorderLeft
{
  border-top: 1px solid #B7B7B7;
  float: left;
  height: 22px;
  line-height: 22px;
  margin: 0 0 0 1px;
  padding: 2px 1px 1px;
  text-align: right;
  vertical-align: middle;
  width: 336px;
}
.customerInfoBlock3
{
  border-left: 1px solid #B7B7B7;
  border-top: 1px solid #B7B7B7;
  float: left;
  height: 22px;
  line-height: 22px;
  margin: 0 0 0 1px;
  padding: 2px 1px 1px;
  text-align: right;
  vertical-align: middle;
  width: 110px;
}
.customerInfoBlock4
{
  border-left: 1px solid #B7B7B7;
  border-top: 1px solid #B7B7B7;
  float: left;
  height: 22px;
  line-height: 22px;
  margin: 0 0 0 1px;
  padding: 2px 1px 1px;
  vertical-align: middle;
  width: 200px;
}
.customerInfoBlock5
{
  border-top: 1px solid #B7B7B7;
  border-left: 1px solid #B7B7B7;
  float: left;
  height: 22px;
  line-height: 22px;
  padding: 2px 1px 1px;
  vertical-align: middle;
  width: 418px;
}
.customerInfoBlock6
{
    font-weight: bold;
    text-align: center;
    float: left;
    width: 837px;
    padding: 2px;
}
.customerInfoBlock7
{
  border-top: 1px solid #B7B7B7;
  float: left;
  height: 22px;
  line-height: 22px;
  padding: 2px 1px 1px;
    text-align: right;
  width: 418px;
}
.customerInfoBlock4NoBorderLeft
{
  border-top: 1px solid #B7B7B7;
  float: left;
  height: 22px;
  line-height: 22px;
  margin: 0 0 0 1px;
  padding: 2px 1px 1px;
  vertical-align: middle;
  width: 201px;
}

.customerInfoViewBlock1
{
  border-left: 1px solid #B7B7B7;
  border-top: 1px solid #B7B7B7;
  float: left;
  height: 22px;
  line-height: 22px;
  margin: 0 0 0 1px;
  padding: 2px 1px 1px;
  text-align: right;
  vertical-align: middle;
  width: 143px;
}
.customerInfoViewBlock2
{
  border-left: 1px solid #B7B7B7;
  border-top: 1px solid #B7B7B7;
  float: left;
  height: 22px;
  line-height: 22px;
  margin: 0 0 0 1px;
  padding: 2px 1px 1px 2px;
  text-align: left;
  vertical-align: middle;
  width: 269px;
}
.customerInfoViewBlock2NoBorderLeft
{
  border-top: 1px solid #B7B7B7;
  float: left;
  height: 22px;
  line-height: 22px;
  margin: 0 0 0 1px;
  padding: 2px 1px 1px 2px;
  text-align: right;
  vertical-align: middle;
  width: 270px;
}
.commission
{
  background-color: #F7F0E4;
  border: 1px solid #B7B7B7;
  float: left;
  min-width: 841px;
  width: 100%;
}
.commissionHeader
{
  color: Black;
  font-weight: bold;
}
.commissionBlock1
{
  border-top: 1px solid #B7B7B7;
  float: left;
  height: 22px;
  text-align: center;
  vertical-align: middle;
  width: 263px;
  padding: 2px 1px 1px;
  text-align: right;
}
.commissionBlock2
{
  border-left: 1px solid #B7B7B7;
  border-top: 1px solid #B7B7B7;
  float: left;
  height: 22px;
  text-align: center;
  vertical-align: middle;
  width: 285px;
  padding: 2px 1px 1px;
}
.commissionViewBlock1
{
  border-top: 1px solid #B7B7B7;
  float: left;
  height: 22px;
  text-align: center;
  vertical-align: middle;
  width: 230px;
  padding: 2px 1px 1px;
  text-align: right;
}
.commissionViewBlock2
{
  border-left: 1px solid #B7B7B7;
  border-top: 1px solid #B7B7B7;
  float: left;
  height: 22px;
  text-align: center;
  vertical-align: middle;
  width: 200px;
  padding: 2px 1px 1px;
}
.commissionGroup
{
  float: left;
  margin-left: 2px;
  padding: 2px 2px 2px 8px;
  white-space: nowrap;
}
.groupCom
{
  text-align: right;
  padding-right: 5px;
}
.widthGroup
{
  width: 60px;
}
.headerTab
{
  background: url("../../_GlobalResources/Images/bg_header02.jpg") repeat-x scroll center top #8C897E;
  clear: both;
  color: #FFFFFF;
  font-size: 12px;
  height: 22px;
  text-align: center;
  text-indent: 5px;
  width: 842px;
}
.transferCondition
{
  background-color: #F7F0E4;
  border-bottom: 1px solid #B7B7B7;
  border-left: 1px solid #B7B7B7;
  border-right: 1px solid #B7B7B7;
  float: left;
  min-width: 840px;
}
.headerPositionTaking
{
  background: url("../../_GlobalResources/Images/bg_header02.jpg") repeat-x scroll center top #8C897E;
  clear: both;
  color: #FFFFFF;
  font-size: 12px;
  height: 22px;
  min-width: 844px;
  text-align: center;
  text-indent: 5px;
  width: 838px;
}
.positionTaking
{
  border-bottom: 1px solid #B7B7B7;
  border-left: 1px solid #B7B7B7;
  border-right: 1px solid #B7B7B7;
  float: left;
  min-width: 838px;
  padding: 2px;
  width: 100%;
}
.line
{
  background-color: #B7B7B7;
  height: 1px;
  margin: 2px 0;
  min-width: 842px;
}
.headerBetSetting
{
  background: url("../../_GlobalResources/Images/bg_header02.jpg") repeat-x scroll center top #8C897E;
  clear: both;
  color: #FFFFFF;
  font-size: 12px;
  height: 22px;
  text-align: center;
  text-indent: 5px;
}
.PTSportLabel2
{
  border-left: 1px solid #838182;
  border-top: 0 none;
}
.PTSportLabel
{
  border-left: 1px solid #838182;
  border-top: 0 none;
}
.PTSport
{
  background: url("ptHeader.png") repeat-x scroll center top;
  border-bottom: 1px solid #B7B7B7;
  border-right: 1px solid #B7B7B7;
  border-top: 1px solid #B7B7B7;
  width: 100%;
}
.PTSportEditCopied
{
}
.PTGroup
{
  background-color: #F7F0E4;
}
.PTGroup2
{
  background-color: #FAF9EE;
}
.BetTypeSelect, .BetTypeLabel, .BetTypeCheckbox
{
  border-left: 1px solid #B7B7B7;
  border-top: 1px solid #B7B7B7;
}
.BetTypeHeader
{
  background-color: #FFEFDE;
  border-left: 1px solid #B7B7B7;
  border-top: 1px solid #B7B7B7;
}
.BetTypeHeader2
{
  border-left: 1px solid #B7B7B7;
  border-top: 1px solid #B7B7B7;
}
.BetTypeHeaderActive
{
  border-left: 1px solid #B7B7B7;
  border-top: 1px solid #B7B7B7;
}
.BetTypeInactive
{
  background-color: #DDDDDD !important;
}
.BetTypeLabel
{
  border-left: 1px solid #B7B7B7;
  border-top: 1px solid #B7B7B7;
}
.GroupLabel
{
  background-color: #FFEFDE;
  border-left: 1px solid #B7B7B7;
  border-top: 1px solid #B7B7B7;
}
.GroupLabel2
{
  background-color: #FFEFDE;
  border-left: 1px solid #B7B7B7;
  border-top: 1px solid #B7B7B7;
}
.GroupSetLabel
{
  background-color: #FFEFDE;
  border-left: 1px solid #B7B7B7;
  border-top: 1px solid #B7B7B7;
  min-width: 60px;
}
.BettingLimit
{
  background-color: #F7F0E4;
  border-bottom: 1px solid #B7B7B7;
  border-right: 1px solid #B7B7B7;
}
.BettingLimit4
{
  background-color: #F7F0E4;
  border-bottom: 1px solid #B7B7B7;
  border-right: 1px solid #B7B7B7;
}
.BettingLimitTextBox
{
  width: 110px !important;
}
.BettingLimitTextBox4
{
  width: 186px !important;
}
.BettingLimitTextBox9
{
  width: 90px !important;
}
.BettingLimitTextBox5
{
  width: 137px !important;
}
.BettingLimitItem
{
  background-color: #F7F0E4;
  border-left: 1px solid #B7B7B7;
  border-top: 1px solid #B7B7B7;
}
.BettingLimitItem4
{
  background-color: #F7F0E4;
  border-left: 1px solid #B7B7B7;
  border-top: 1px solid #B7B7B7;
}
.BettingLimitItem5
{
  background-color: #F7F0E4;
  border-left: 1px solid #B7B7B7;
  border-top: 1px solid #B7B7B7;
}
.BettingLimitItem9
{
  background-color: #F7F0E4;
  border-left: 1px solid #B7B7B7;
  border-top: 1px solid #B7B7B7;
}
.BettingLimitItem92
{
  background-color: #F7F0E4;
  border-left: 0px;
  border-top: 1px solid #B7B7B7;
  min-width: 76px;
}
.BettingLimitItem2
{
  background-color: #F7F0E4;
  border-top: 1px solid #B7B7B7;
}
.BettingLimitHeader
{
  border-left: 1px solid #B7B7B7;
  border-top: 1px solid #B7B7B7;
}
.BettingLimitHeader2
{
  border-left: 1px solid #B7B7B7;
  border-top: 1px solid #B7B7B7;
}
.BettingLimitHeaderCopied
{
  background-position: 100px 2px;
  border-left: 1px solid #B7B7B7;
  border-top: 1px solid #B7B7B7;
}
.BettingLimitHeaderCopiedActive
{
  background-position: 100px 2px;
  border-left: 1px solid #B7B7B7;
  border-top: 1px solid #B7B7B7;
}
.BettingLimitHeaderTop
{
  border-left: 1px solid #B7B7B7;
  border-top: 1px solid #B7B7B7;
}
.BettingLimitHeaderTop9
{
  border-left: 1px solid #B7B7B7;
  border-top: 1px solid #B7B7B7;
}
.BettingLimitHeaderTop4
{
  border-left: 1px solid #B7B7B7;
  border-top: 1px solid #B7B7B7;
}
.BettingLimitHeaderTop5
{
  border-left: 1px solid #B7B7B7;
  border-top: 1px solid #B7B7B7;
}
.BettingLimitLabel
{
  border-left: 1px solid #B7B7B7;
  border-top: 1px solid #B7B7B7;
}
.BettingLimitLabel1
{
  border-left: 1px solid #B7B7B7;
  border-top: 1px solid #B7B7B7;
}
.PTBoxRightBorder .BetTypeHeader, .PTBoxRightBorder .BetTypeSelect, .PTBoxRightBorder .BetTypeLabel {
    border-right: 1px solid #B7B7B7;
}
.BetTypeBottomBorder {
    border-bottom: 1px solid #B7B7B7;
    height: 22px !important;
}

.PTGroupSet2 {
    background-color: #FAF9EE!important;
    clear: both;
    margin: 0;
    overflow: auto;
    padding: 0;
}
.divEdit
{
  background: url(../../_GlobalResources/Images/edit.gif) no-repeat scroll 0 0 transparent;
  cursor: pointer;
  height: 17px;
  width: 17px;
}

td, span, div, a
{
  font-family: Tahoma,Arial,helvetica,sans-serif;
  font-size: 11px;
}

.loading1
{
  background: url(../../_GlobalResources/Images/ajax-loader.gif) no-repeat top;
  display: block;
  height: 32px;
  width: 32px;
}

div.divBoxRight
{
  float: right;
  padding-right: 4px;
  padding-top: 4px;
}

.AGEWnd
{
  -moz-border-radius: 3px 3px 2px 2px;
  -webkit-border-radius: 3px 3px 2px 2px;
  background-color: #eee;
  border: 1px solid #000;
  border-collapse: collapse;
  border-radius: 3px 3px 2px 2px 2px;
  margin: 0;
  padding: 0;
}

.AGEWndMask
{
  background-color: transparent;
  border: dashed 2px #999;
  border-style: dotted;
  cursor: move;
  z-index: 1002;
}

.AGEWndTitleMask
{
  -khtml-opacity: 0.01;
  -moz-opacity: .01;
  background-color: #727272;
  border: solid 0 #ff;
  border-style: none;
  cursor: move;
  filter: alpha(opacity=01);
  height: 20px;
  left: 0;
  margin: 0;
  opacity: 0.01;
  padding: 0;
  position: absolute;
  top: 0;
  z-index: 1002;
}

.AGEWndTable
{
  border: solid 0 transparent;
  cursor: default;
  margin: 0;
  padding: 0;
  table-layout: fixed;
  width: 100%;
}

.AGEWndTitle
{
  -moz-user-select: no;
  background: #000 url(../Images/bg_popup.jpg) repeat scroll 0 0;
  background-color: #727272;
  color: #fff;
  font-weight: 700;
  margin: 0;
  padding: 0;
}

.AGEWndTitleDiv
{
  font-size: 12px;
  font-weight: 700;
}

.AGEWndTitleText
{
  cursor: pointer;
  text-align: left;
}

.AGEWndTitleButton
{
  height: 20px;
  overflow: hidden;
  padding-right: 1px;
  text-align: right;
  width: 20px;
}

.AGEWndCloseButton
{
  background-image: url(../Images/x.jpg);
  cursor: pointer;
  display: block;
  height: 15px;
  line-height: 0;
  width: 15px;
}

.AGEWndNoPadding
{
  margin: 0;
  padding: 0;
}

.clssBackground
{
  background-color: #f8b72b;
}

.btnLeft
{
  background: url(../Images/b_left.gif) no-repeat left top;
  height: 22px;
  margin: 5px 0;
  min-width: 64px;
  padding: 0 0 0 3px;
}

.btnRight
{
  background: url(../Images/b_left.gif) no-repeat left top;
  height: 22px;
  margin: 5px 0;
  min-width: 64px;
  padding: 0 0 0 3px;
  float: right;
}

.btnMain
{
  background: url(../Images/b_right.gif) no-repeat right top;
  border: none;
  color: #333;
  cursor: pointer;
  display: block;
  float: left;
  font-size: 12px;
  font-weight: 700;
  height: 22px;
  min-width: 64px;
  padding: 0 24px 2px 12px;
}

.btnMain:hover
{
  background-position: 100% -22px;
  color: #000;
  cursor: pointer;
}

input[type=submit], input[type=reset], table
{
  -moz-border-radius: 3px;
  -webkit-border-radius: 3px;
  border-radius: 3px;
}

input[type=text], input[type=password]
{
  width: 120px;
}

.tblRpt td, .tblPop td
{
  line-height: 22px;
  padding-left: 2px;
  padding-right: 2px;
}
.successWarning
{
  background-image: url("../../../_GlobalResources/Images/tick.png");
  padding-left: 5px;
  background-repeat: no-repeat;
  letter-spacing: 10px;
  font-size: 12px;
}
.errorWarning
{
  background-image: url("../../../_GlobalResources/Images/x5.gif");
  padding-left: 5px;
  background-repeat: no-repeat;
  letter-spacing: 10px;
  font-size: 12px;
}
.successWarning2
{
  background-image: url("../../_GlobalResources/Images/tick.png");
  padding-left: 5px;
  background-repeat: no-repeat;
  letter-spacing: 10px;
  font-size: 12px;
}
.errorWarning2
{
  background-image: url("../../_GlobalResources/Images/x5.gif");
  padding-left: 5px;
  background-repeat: no-repeat;
  letter-spacing: 10px;
  font-size: 12px;
}
.loading2
{
  background-image: url(../../_MemberInfo/P2P/Resources/Images/loading.gif);
  background-repeat: no-repeat;
  background-position: center center;
}

button[disabled]:active, button[disabled],
input[type="reset"][disabled]:active,
input[type="reset"][disabled],
input[type="button"][disabled]:active,
input[type="button"][disabled],
input[type="submit"][disabled]:active,
input[type="submit"][disabled] {
    opacity:0.6;
    filter:alpha(opacity=60); /* For IE8 and earlier */
  color: #000;
  cursor: pointer;
}

.infoIco
{
  cursor: pointer;
  background: url("../../_GlobalResources/Images/info.png") no-repeat right;
  width: 20px;
}
            #header_main
{
  min-width: 350px;
  width: 350px;
}
        .jlhlebbhengjlhmcjebbkambaekglhkf {
        top:0px;
        left:0px;
        min-width:30px;
        max-width:300px;
        font-size:13px;
        font-family:arial,helvetica,sans-serif;
        opacity:.93;
        padding:0px;
        position:absolute;
        display:block;
        z-index:999997;
        font-style:normal;
        font-variant:normal;
        font-weight:normal;
        }

        #jlhlebbhengjlhmcjebbkambaekglhkf_up {
        text-align:center;
        padding:0px;
        margin:0px;
        }

        #jlhlebbhengjlhmcjebbkambaekglhkf_cont {
        background-color:#729FCF;
        font-family:arial,helvetica,sans-serif-webkit-box-shadow:#729FCF 0px 0px 2px;
        color:#FFFFFF;
        padding:7px;
        -webkit-border-radius:5px;
        }

        #jlhlebbhengjlhmcjebbkambaekglhkf_down {
        text-align:center;
        padding:0px;
        margin:0px;
        }
        .btnMain{
          background-color: rgb(140, 137, 125);
          color: rgb(255, 255, 255);
        }
      </style>
</head>
    <?php echo $__env->make('portal.messsage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <body id="bdSearch" onload="showmessage('<?php echo e($errorMsg); ?>')">
    <?php echo Form::model(array('route' => array('portal.web.updateBetsMemberPost', $user->id))); ?>

    <input type="hidden" name="mb" value="<?php echo e($user->username); ?>">
        <div id="header_main" class="pt7">Tùy chỉnh thiết lập về tiền cược <?php echo e($user->username); ?></div>
        <div class="minWidthCustomer pt3">
            <link href="/_Components/ErrorMsg/ErrorMsg.css?20141103" rel="stylesheet" type="text/css">
            <script src="/_Components/ErrorMsg/ErrorMsg.js?20141103" type="text/javascript"></script>
            <table border="0" cellpadding="0" cellspacing="0" width="100%" id="diverrmsg" style="display: none;">
                <tbody>
                    <tr>
                        <td id="msg_1_1" class="emsg_1_1">&nbsp;</td>
                        <td id="msg_1_2" class="emsg_1_2">&nbsp;</td>
                        <td id="msg_1_3" class="emsg_1_3">&nbsp;</td>
                    </tr>
                    <tr>
                        <td id="msg_2_1" valign="top" class="emsg_2_1">&nbsp;</td>
                        <td valign="top" id="spmsgerr" class="msgerr"></td>
                        <td id="msg_2_2" class="emsg_2_2">&nbsp;</td>
                    </tr>
                    <tr>
                        <td id="msg_3_1" class="emsg_3_1">&nbsp;</td>
                        <td id="msg_3_2" class="emsg_3_2">&nbsp;</td>
                        <td id="msg_3_3" class="emsg_3_3">&nbsp;</td>
                    </tr>
                </tbody>
            </table>
        </div>
        <input type="hidden" name="txtCustomerObject" id="txtCustomerObject">
        <div class="headerBetSetting" >Tiền Cược</div>
         <div id="bettingLimitContainer">
    <div class="BettingLimit">
    <table border="0.9" style="width: 100%;">
    <tbody><tr>
        <td width="25%"></td>
        <td width="25%">Nhỏ Nhất</td>
        <td width="25%">Lớn Nhất</td>
        <td width="25%">Tiền cược lớn nhất trong 1 trận</td>
    </tr>
    <tr>
        <td style="border: 1px;">Bóng Đá</td>
        <td>
          <input style="text-align: right;" name="bongdamin" class="BettingLimitTextBox" min="1" max="1000000" value="<?php echo e($user->bongdamin); ?>" maxlength="14" type="number" required=""> &gt;=1</td>
        <td><input style="text-align: right;" name="bongdamax" class="BettingLimitTextBox" min="1" max="1000000" value="<?php echo e($user->bongdamax); ?>" maxlength="14" type="number" required=""> &lt;=1000000</td>
        <td><input style="text-align: right;" name="bongdaper" class="BettingLimitTextBox" min="1" max="1000000" value="<?php echo e($user->bongdaper); ?>" maxlength="14" type="number" required=""> &lt;=1000000</td>
    </tr>
    <tr>
        <td>Bóng Rổ</td>
        <td><input style="text-align: right;" name="bongromin" class="BettingLimitTextBox" min="0" max="1000000" value="<?php echo e($user->bongromin); ?>" maxlength="14" type="number" required=""> &gt;=1</td>
        <td><input style="text-align: right;" name="bongromax" class="BettingLimitTextBox" min="0" max="1000000" value="<?php echo e($user->bongromax); ?>" maxlength="14" type="number" required=""> &lt;=1000000</td>
        <td><input style="text-align: right;" name="bongroper" class="BettingLimitTextBox" min="0" max="1000000" value="<?php echo e($user->bongroper); ?>" maxlength="14" type="number" required=""> &lt;=1000000</td>
    </tr>
    <tr>
        <td>Tennis</td>
        <td><input style="text-align: right;" name="bauducmin" class="BettingLimitTextBox" min="0" max="1000000" value="<?php echo e($user->bauducmin); ?>" maxlength="14" type="number" required=""> &gt;=1</td>
        <td><input style="text-align: right;" name="bauducmax" class="BettingLimitTextBox" min="0" max="1000000" value="<?php echo e($user->bauducmax); ?>" maxlength="14" type="number" required=""> &lt;=1000000</td>
        <td><input style="text-align: right;" name="bauducper" class="BettingLimitTextBox" min="0" max="1000000" value="<?php echo e($user->bauducper); ?>" maxlength="14" type="number" required=""> &lt;=1000000</td> 
    </tr>
    </tbody></table>
    </div>
  </div>
        <div class="clearBlock"></div>
        <div class="pt7">
            <div class="btnLeft">
                <input type="submit" id="btnSubmit" class="btnMain" value="Cập Nhật">
            </div>
        </div>
    <?php echo Form::close(); ?>

    <script type="text/javascript">
      function showmessage(msg) {
        if (!!msg) {
          alert(msg);
        }
      }
    </script>
  </body>
  </html>