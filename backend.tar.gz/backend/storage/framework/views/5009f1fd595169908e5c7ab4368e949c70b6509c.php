<div class="error">
	<?php if(isset($successMsg)): ?>
	<p style="color: green"><?php echo e($successMsg); ?></p>
	<?php elseif(\Session::has('successMsg')): ?>
	<p style="color: green"><?php echo \Session::get('successMsg'); ?></p>
	<?php endif; ?>
	<?php if(isset($errorMsg)): ?>
	<p style="color: red"><?php echo e($errorMsg); ?></p>
	<?php elseif(\Session::has('errorMsg')): ?>
	<p style="color: red"><?php echo \Session::get('errorMsg'); ?></p>
	<?php endif; ?>

	
	<script type="text/javascript">

		<?php if(\Session::has('script')): ?>
		<?php echo \Session::get('script'); ?>

		<?php endif; ?>

		var message = '';
		var show = false
		<?php if(isset($successMsg)): ?>
			show = true;
			message = '<?php echo e($successMsg); ?>';
		<?php elseif(\Session::has('successMsg')): ?>
			show = true;
			message = '<?php echo \Session::get('successMsg'); ?>';
		<?php endif; ?>
		<?php if(isset($errorMsg)): ?>
			show = true;
			message = '<?php echo e($errorMsg); ?>';
		<?php elseif(\Session::has('errorMsg')): ?>
			show = true;
			message = '<?php echo \Session::get('errorMsg'); ?>';
		<?php endif; ?>
	</script>
</div>