<!-- <div id="xp" style="position: absolute; overflow: hidden; border: 0px solid rgb(255, 0, 0); z-index: 65531 !important; width: 172px; height: 245px; left: 7px; bottom: 0px;">
    <div id="xp_content" style="position: absolute; z-index: 1; overflow: hidden; border-width: 0px; width: 172px; height: 245px; left: 0px; top: 0px;">
      <a id="closeButton" href="#"></a>
      <a id="switchButton" href="#" onclick="toggleMini()" style="position: absolute; color: rgb(255, 255, 255); z-index: 2; width: 172px; height: 24px; font-family: Tahoma; font-weight: bold; font-size: 12px; text-align: left; line-height: 24px; left: 0px; top: 0px; background-image: url(&quot;https://ca88.155551.com/MiniWebPortal/img/mini_header_btn_close_s2-1.gif&quot;);">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Trò chơi Mini</a>
        <div
            id="ifm_div" style="height:245px;">
            <iframe id="xp_content_iframe" src="https://ca88.155551.com/MiniWebPortal/MiniFrame.aspx?o=zfa3DWMG9j12rBhSG9iI1J39sOj7JCcGH4BY7ZtvVb%2bF5iLNzlcQUBq2TQ2WNQ2FTXwWDzwJAznaTh8D8w0YNGG4ts2EtnXVhvgA69SkJ7vCkSu%2bIJA%2fdYtInRkEM8Uau2mzM8L1BRHDkC%2bMcQVXpFS6pYMxB03B%2b08qEdCshgf7bWAmn%2fVSsr5k%2bFSFtra4O4iBPAeSEnfpWodpqMppT%2frdTGMElkMGki1j%2b0iLjuUldoUgvOa9DlrHsZMwg2RCky%2fjABjztjk%3d"
                frameborder="0" scrolling="no" width="100%" height="100%" allowtransparency="true"></iframe>
    </div>
</div>
</div> -->
<!-- <script type="text/javascript">
  var heightBar = 0;
  function toggleMini() {
    if (heightBar) {
      heightBar = 0
    } else {
      heightBar = 224;
    }
    relayout();
  }

  function relayout(argument) {
    var windowTop = $(window).scrollTop(); //
    $('#xp').css('bottom', -(heightBar + windowTop)+'px');
  }

  $(window).scroll(relayout);
</script> -->