<div class="error">
	<script type="text/javascript">
		alert('Phiên đăng nhập của quý khách đã hết hạn , vui lòng đăng nhập lại.');
		top.location = '/portal/login'
		location = '/portal/login'
	</script>
</div>