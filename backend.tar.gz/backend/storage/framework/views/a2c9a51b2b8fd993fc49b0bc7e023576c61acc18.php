<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>VOID/REJECTED BET LIST (LAST 1 WEEK)</title>
<link href="/assets/admin/css/cuochuy_files/Reports.min.css" rel="stylesheet" type="text/css">
<link href="/assets/admin/css/cuochuy_files/BetList.min.css" rel="stylesheet" type="text/css">
<style type="text/css"></style>

</head>
<body>
<?php echo $__env->make('portal.messsage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<form id="frmCancelBetList" method="get">
  <div class="bl_title">Danh sách đặt cược bị Hủy/ Từ Chối (cách đây 1 tuần )
    <div class="divBoxRight">
      
    </div>
  </div>
  <div id="content">
    <table id="hor-minimalist-a">
      <thead>
        <tr>
          <th style="width: 20px;">#</th>
          <th style="width: 110px;">Thành viên</th>
          <th style="width: 110px;">Thời gian</th>
          <th>Lựa chọn</th>
          <th style="width: 50px;">Tỷ lệ</th>
          <th style="width: 50px;">Tiền cược</th>
          <th style="width: 75px;">Trạng thái</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $bets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr style="text-decoration: line-through;">
          <td style="width: 20px;text-align: center;">Ref No:<?php echo e($item->id); ?></td>
          <td style="width: 110px;text-align: center;"><?php echo e($item->username); ?></td>
          <td style="width: 110px;text-align: center;"><?php echo e($item->date); ?></td>
          <td>
            <div>
              <div class="">
                <span class="underdog"><?php echo e($item->bet_name); ?> 
                  <span class="handicap"><?php echo e($item->bet_amount); ?></span>
                  <span>[<?php echo e($item->ss); ?>]</span></span>
                  <div class="bettype"><?php echo e($item->bet_type); ?></div>
                  <div class="match">
                    <span><?php echo e($item->home); ?></span><span>&nbsp;-&nbsp;vs&nbsp;-&nbsp;</span><span><?php echo e($item->away); ?></span>
                  </div>

                <div class="league">
                  <span class="sport">Bóng đá</span><span class="leagueName">&nbsp;<?php echo e($item->league_name); ?></span>
                </div>
              </div>
            </div>
          </td>
          <td style="width: 50px;"><font color="#B50000"><?php echo e($item->bet_value); ?></font><br>MY</td>
          <td style="width: 50px;"><?php echo e($item->bet_amount); ?></td>
          <td style="width: 75px;text-align: center;">Đã Hủy</td>
          <td style="width: 75px;text-align: center;">Đã Hủy <br> HT: <?php echo e($item->last_ss); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
</form>
</body>
</html>