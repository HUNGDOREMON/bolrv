<?php $__env->startSection('menu', 'statement'); ?>
<?php $__env->startSection('main'); ?>
    <div class="account">
        <!--start-->
        <div class="content">

            <div class="caption">
                <div class="filterArea ">
                    <div class="filter icon-print" title="In Trang Này" target="_self" onclick="window.print()"></div>
                    <div class="filter icon-refresh  " title="Tải Lại" onclick="window.location.reload();"> </div>
                </div>
                <div class="mainTitle icon-betList">Bảng Cược</div>
            </div>

            <div class="accountTable-verticalAlignTop">
                <div class="tableHead">
                    <div class="no">Số.</div>
                    <div class="date">Ngày</div>
                    <div class="choice">Chọn</div>
                    <div class="odds">Tỷ lệ cược</div>
                    <div class="stake">Tiền cọc</div>
                    <div class="stake">Thắng/Thua</div>
                    <div class="status">Trạng Thái</div>
                </div>
                <div class="tableBody">
                    <?php $__currentLoopData = $bets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $bet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="tableRow <?php echo e($bet->bet_status_name == 'Cược bất thường' ? 'background-cbt' : ''); ?>">
                            <div class="no"><?php echo e($key + 1); ?></div>
                            <div class="date">
                                <div class="ref">Ref No.:<?php echo e($bet->id); ?></div>
                                <div><?php echo e($bet->date); ?></div>
                            </div>
                            <div class="choice">
                                <div class="betInfo <?php echo e($bet->bet_status_name == 'Cược bất thường' ? 'text-decoration' : ''); ?>">
                                    <div class="ticketType hiddenElement">
                                        <div class="smallBtn  primary icon-next hiddenElement"
                                            onclick="toggleComboList('103900524726', this);"></div> <span></span>
                                    </div>
                                    <div class="mainInfo">
                                        <div class="betDetial">
                                        </div>
                                    </div>
                                    <?php if($bet->bet_kind == 'normal'): ?>
                                        <div id="103900524726" class="">
                                            <div class="mainInfo ">
                                                <?php if($bet->bet_type == 'Điểm số chính xác'): ?>
                                                    <div class="betType"><?php echo e($bet->bet_type); ?> - [<?php echo e($bet->type); ?>]</div>
                                                    <div class="betDetial">                                                    
                                                        <div class="oddsDetail">
                                                            <span class="selectorName"><?php echo e($bet->bet_odd); ?><span
                                                                    class="hiddenElement"></span></span>
                                                            <span class="selectorScore">[<?php echo e($bet->ss); ?>]</span>
                                                            <span
                                                                class="selectorOdds <?php echo e($bet->bet_value < 0 ? 'accent' : ''); ?>"><?php echo e($bet->bet_value); ?></span>
                                                            <span class="selectorOther"></span>

                                                        </div>
                                                        <div class="otherDetail">

                                                        </div>
                                                    </div>
                                                <?php else: ?>
                                                    <div class="betType">Bóng đá / <?php echo e($bet->bet_type); ?></div>
                                                    <div class="betDetial">
                                                        <div class="name"><?php echo e($bet->bet_name); ?></div>
                                                        <div class="oddsDetail">
                                                            <span class="selectorName"><?php echo e($bet->bet_odd); ?><span
                                                                    class="hiddenElement"></span></span>
                                                            <span class="selectorScore">[<?php echo e($bet->ss); ?>]</span>
                                                            <span
                                                                class="selectorOdds <?php echo e($bet->bet_value < 0 ? 'accent' : ''); ?>"><?php echo e($bet->bet_value); ?></span>
                                                            <span class="selectorOther"></span>

                                                        </div>
                                                        <div class="otherDetail">

                                                        </div>
                                                    </div>
                                                <?php endif; ?>

                                                <div class="matchInfo-line">                                                   
                                                    <div class="homeName" title="<?php echo e($bet->home); ?>">
                                                        <?php echo e($bet->home); ?></div>
                                                    <div class="awayName" title="<?php echo e($bet->away); ?>">
                                                        <?php echo e($bet->away); ?></div>
                                                    <div class="leagueName" title="<?php echo e($bet->league_name); ?>">
                                                        <?php echo e($bet->league_name); ?></div>
                                                    <div></div>
                                                    <div></div>

                                                </div>
                                            </div>
                                        </div>
                                    <?php else: ?>
                                        <div id="103900524726" class="">
                                            <?php $__currentLoopData = $bet->bets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="mainInfo">
                                                    <div class="betType">Bóng đá / <?php echo e($value->bet_type); ?></div>
                                                    <div class="betDetial">
                                                        <div class="name"><?php echo e($value->bet_name); ?></div>
                                                        <div class="oddsDetail">
                                                            <span class="selectorName"><?php echo e($value->bet_odd); ?><span
                                                                    class="hiddenElement"></span></span>
                                                            <span class="selectorScore">[<?php echo e($value->ss); ?>]</span>
                                                            <span
                                                                class="selectorOdds <?php echo e($value->bet_value < 0 ? 'accent' : ''); ?>"><?php echo e($value->bet_value); ?></span>
                                                            <span class="selectorOther"></span>

                                                        </div>
                                                        <div class="otherDetail">

                                                        </div>
                                                    </div>
                                                    <div class="matchInfo-line">
                                                        <div></div>
                                                        <div></div>
                                                        <div></div>
                                                        <div class="homeName" title="<?php echo e($value->home); ?>">
                                                            <?php echo e($value->home); ?></div>
                                                        <div class="awayName" title="<?php echo e($value->away); ?>">
                                                            <?php echo e($value->away); ?></div>
                                                        <div class="leagueName" title="<?php echo e($value->league_name); ?>">
                                                            <?php echo e($value->league_name); ?></div>
                                                        <div></div>
                                                        <div></div>

                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    <?php endif; ?>
                                    <div class=""></div>
                                    <div class=""></div>
                                    <div class=""></div>
                                    <div></div>
                                    <div></div>
                                </div>
                            </div>
                            <div class="odds">
                                <div class="point <?php echo e($bet->rate < 0 ? 'accent' : ''); ?>"><?php echo e($bet->rate); ?></div>MY
                            </div>
                            <div class="stake">
                                <div class="strikeThrough"></div><?php echo e($bet->bet_amount); ?>

                            </div>
                            <div class="odds" style="font-weight: bold;">
                                <span class="<?php echo e($bet->bet_profit < 0 ? 'accent' : ''); ?>"><?php echo e($bet->bet_profit); ?></span>
                                <br />
                                <?php echo e($bet->bet_commission); ?>

                            </div>
                            <div class="status">
                                <div style="color: #606060; font-weight: bold;"><?php echo e($bet->bet_status_name); ?></div>
                                <?php if($bet->bet_kind == 'normal'): ?>
                                    <div style="color: black; font-weight: bold;">KT: <?php echo e($bet->last_ss); ?></div>
                                <?php endif; ?>
                                <?php if($bet->ip_address): ?>
                                    <div>From:</div>
                                    <div><?php echo e($bet->ip_address); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <?php if(isset($betsInfo)): ?>
                    <div class="tableFooter">
                        <div class="tableFooterRow">
                            <div class="total">Tổng phụ</div>
                            <div class="stake"></div>
                            <div class="credit <?php echo e($betsInfo->profit < 0 ? 'accent' : ''); ?>">
                                <?php echo e(format_number_pretty($betsInfo->profit)); ?></div>
                            <div class="status"></div>
                        </div>
                        <div class="tableFooterRow">
                            <div class="total">Tổng phụ (Hoa Hồng)</div>
                            <div class="stake"></div>
                            <div class="credit"><?php echo e(format_number_pretty($betsInfo->commission, 2)); ?></div>
                            <div class="status"></div>
                        </div>
                        <div class="tableFooterRow">
                            <div class="total">Tổng cộng</div>
                            <div class="stake"></div>
                            <div class="credit <?php echo e($betsInfo->profit + $betsInfo->commission < 0 ? 'accent' : ''); ?>">
                                <?php echo e(format_number_pretty($betsInfo->profit + $betsInfo->commission)); ?></div>
                            <div class="status"></div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
            <div class="note">
                <div class="title">Lưu ý</div>
                <div class="txt">Xin lưu ý rằng thời gian hiển thị dựa trên GMT -4 giờ.</div>
            </div>

            <div class="popupPanel-large" id="MoreDiv" style="display: none">
                <div class="heading-default " id="MoreTitle">
                    <div class="floatRight">
                        <button id="MoreCloser" class="glyphIcon-large secondary icon-close" title="Close"></button>
                    </div>
                    <div id="MoreTitleValue" class="text" title=""></div>
                </div>
                <div class="contentArea">
                    <div id="oPopContainer"></div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.v2.iframe.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>