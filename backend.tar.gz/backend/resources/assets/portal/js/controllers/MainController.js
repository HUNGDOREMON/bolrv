angular.module('portal').controller('MainController', ['$scope', '$location', '$localStorage',
  function ($scope, $location, $localStorage) {
    
  }
]);
