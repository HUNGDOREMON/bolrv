angular.module('todoApp').controller('BetsController', ['$scope', '$location', '$localStorage', 'leaguesAPI', '$templateCache',
  function ($scope, $location, $localStorage, leaguesAPI, $templateCache) {
  }
]);
